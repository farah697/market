﻿namespace ornek_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtBarkod = new TextBox();
            txtAd = new TextBox();
            txtFiyat = new TextBox();
            txtStok = new TextBox();
            btnEkle = new Button();
            btnSil = new Button();
            btnListele = new Button();
            btnToplamDeger = new Button();
            lstUrunler = new ListBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // txtBarkod
            // 
            txtBarkod.Location = new Point(12, 19);
            txtBarkod.Name = "txtBarkod";
            txtBarkod.PlaceholderText = "Barkod";
            txtBarkod.Size = new Size(188, 27);
            txtBarkod.TabIndex = 0;
            // 
            // txtAd
            // 
            txtAd.Location = new Point(12, 52);
            txtAd.Name = "txtAd";
            txtAd.PlaceholderText = "Ad";
            txtAd.Size = new Size(188, 27);
            txtAd.TabIndex = 1;
            // 
            // txtFiyat
            // 
            txtFiyat.Location = new Point(12, 85);
            txtFiyat.Name = "txtFiyat";
            txtFiyat.PlaceholderText = "Fiyat";
            txtFiyat.Size = new Size(188, 27);
            txtFiyat.TabIndex = 2;
            // 
            // txtStok
            // 
            txtStok.Location = new Point(12, 118);
            txtStok.Name = "txtStok";
            txtStok.PlaceholderText = "Stok";
            txtStok.Size = new Size(188, 27);
            txtStok.TabIndex = 3;
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(12, 151);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(92, 29);
            btnEkle.TabIndex = 5;
            btnEkle.Text = "Ekle";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // btnSil
            // 
            btnSil.Location = new Point(12, 186);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(92, 29);
            btnSil.TabIndex = 6;
            btnSil.Text = "Sil";
            btnSil.UseVisualStyleBackColor = true;
            btnSil.Click += btnSil_Click;
            // 
            // btnListele
            // 
            btnListele.Location = new Point(108, 151);
            btnListele.Name = "btnListele";
            btnListele.Size = new Size(92, 29);
            btnListele.TabIndex = 7;
            btnListele.Text = "Listele";
            btnListele.UseVisualStyleBackColor = true;
            btnListele.Click += btnListele_Click;
            // 
            // btnToplamDeger
            // 
            btnToplamDeger.Location = new Point(110, 186);
            btnToplamDeger.Name = "btnToplamDeger";
            btnToplamDeger.Size = new Size(92, 29);
            btnToplamDeger.TabIndex = 8;
            btnToplamDeger.Text = "Toplam Değer";
            btnToplamDeger.UseVisualStyleBackColor = true;
            btnToplamDeger.Click += btnToplamDeger_Click;
            // 
            // lstUrunler
            // 
            lstUrunler.FormattingEnabled = true;
            lstUrunler.Location = new Point(207, 33);
            lstUrunler.Name = "lstUrunler";
            lstUrunler.Size = new Size(254, 184);
            lstUrunler.TabIndex = 9;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(278, 9);
            label1.Name = "label1";
            label1.Size = new Size(90, 20);
            label1.TabIndex = 10;
            label1.Text = "Tüm Ürünler";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(468, 235);
            Controls.Add(label1);
            Controls.Add(lstUrunler);
            Controls.Add(btnToplamDeger);
            Controls.Add(btnListele);
            Controls.Add(btnSil);
            Controls.Add(btnEkle);
            Controls.Add(txtStok);
            Controls.Add(txtFiyat);
            Controls.Add(txtAd);
            Controls.Add(txtBarkod);
            Name = "Form1";
            Text = "Market Ürün Takip Sistemi";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtBarkod;
        private TextBox txtAd;
        private TextBox txtFiyat;
        private TextBox txtStok;
        private Button btnEkle;
        private Button btnSil;
        private Button btnListele;
        private Button btnToplamDeger;
        private ListBox lstUrunler;
        private Label label1;
    }
}

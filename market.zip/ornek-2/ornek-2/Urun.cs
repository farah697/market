﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ornek_1
{
    public class Urun
    {
        public string barkod;
        public string ad;
        public double fiyat;
        public int stokAdedi;

        public Urun(string barkod, string ad, double fiyat, int stokAdedi)
        {
            this.barkod = barkod;
            this.ad = ad;
            this.fiyat = fiyat;
            this.stokAdedi = stokAdedi;
        }
    }

}

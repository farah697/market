﻿using ornek_1;

namespace ornek_2
{
    public partial class Form1 : Form
    {
        Market market;
        public Form1()
        {
            InitializeComponent();
            market = new Market();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            string barkod = txtBarkod.Text;
            string ad = txtAd.Text;
            double fiyat;
            int stok;

            if (!double.TryParse(txtFiyat.Text, out fiyat) || !int.TryParse(txtStok.Text, out stok))
            {
                MessageBox.Show("Fiyat ve stok sayıları geçerli değil.");
                return;
            }

            Urun yeniUrun = new Urun(barkod, ad, fiyat, stok);
            market.UrunEkle(yeniUrun);

            MessageBox.Show("Ürün eklendi!");
            Temizle();
        }

        private void Temizle()
        {
            txtBarkod.Text = "";
            txtAd.Text = "";
            txtFiyat.Text = "";
            txtStok.Text = "";
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            string barkod = txtBarkod.Text;
            market.UrunSil(barkod);
            MessageBox.Show("Ürün silindi (eğer varsa).");
        }

        private void btnToplamDeger_Click(object sender, EventArgs e)
        {
            double toplam = market.ToplamStokDegeri();
            MessageBox.Show("Toplam stok değeri: " + toplam + " TL");
        }

        private void btnListele_Click(object sender, EventArgs e)
        {
            lstUrunler.Items.Clear(); // Önce eski öğeleri temizle

            foreach (Urun urun in market.UrunleriGetir())
            {
                string satir = "Barkod: " + urun.barkod +
                               ", Ad: " + urun.ad +
                               ", Fiyat: " + urun.fiyat +
                               ", Stok: " + urun.stokAdedi;

                lstUrunler.Items.Add(satir);
            }
        }
    }
}

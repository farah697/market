﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ornek_1
{
    public class Market
    {
        private List<Urun> urunler;

        public Market()
        {
            urunler = new List<Urun>();
        }

        public void UrunEkle(Urun urun)
        {
            urunler.Add(urun);
        }

        public void UrunSil(string barkod)
        {
            for (int i = 0; i < urunler.Count; i++)
            {
                if (urunler[i].barkod == barkod)
                {
                    urunler.RemoveAt(i);
                    break;
                }
            }
        }

        public Urun UrunBul(string barkod)
        {
            foreach (Urun urun in urunler)
            {
                if (urun.barkod == barkod)
                    return urun;
            }
            return null;
        }

        public double ToplamStokDegeri()
        {
            double toplam = 0;
            foreach (Urun urun in urunler)
            {
                toplam += urun.stokAdedi * urun.fiyat;
            }
            return toplam;
        }

        public List<Urun> UrunleriGetir()
        {
            return urunler;
        }
    }

}
